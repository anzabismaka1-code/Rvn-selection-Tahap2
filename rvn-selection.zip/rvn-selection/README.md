# RVN Selection Portal

Proyek awal Next.js untuk seleksi wawancara situasional RVN (20 soal, 30 menit), Supabase dan Vercel. UI peserta, login admin Supabase Auth, tabel hasil, laporan kejadian dan ekspor CSV tersedia.

## Penting sebelum dipakai sungguhan

- Ini starter project yang perlu dikonfigurasi dan diuji; belum online hanya dengan mengunduh ZIP.
- SQL schema sudah menyertakan 20 soal situasional beserta kunci rekomendasi awal. Tinjau dan sesuaikan semua kunci bersama tim RVN sebelum seleksi resmi; kode soal harus `q1` sampai `q20` dan urutan opsi harus sesuai layar.
- Jawaban pada tes situasional sebaiknya ditetapkan oleh tim RVN. Jangan gunakan kunci contoh yang belum disepakati.
- Berpindah tab/aplikasi yang memicu `visibilitychange` dikirim sebagai laporan dan mengakhiri ujian sesuai pengaturan default. Kehilangan fokus jendela hanya dicatat. Peristiwa browser tidak membuktikan kecurangan dan harus dijelaskan di aturan seleksi; uji di Android terlebih dahulu.
- Buat akun admin lewat Supabase Authentication > Users, lalu masukkan UUID akun ke `rvn_admins` dari SQL Editor. Jangan pernah menaruh service-role key di browser/Vercel `NEXT_PUBLIC_*`.

## A. Buat backend Supabase

1. Buat project baru di Supabase.
2. Buka SQL Editor, jalankan seluruh isi `supabase/schema.sql`.
3. Ganti token awal:

```sql
update public.rvn_settings set exam_token='TOKEN-RAHASIA-BARU', updated_at=now() where id=true;
```

4. Periksa 20 soal awal yang otomatis ditambahkan oleh SQL. Tinjau kunci rekomendasi di `rvn_questions` sebelum ujian resmi.

5. Buat akun admin di Authentication > Users. Salin UUID user, lalu jalankan:

```sql
insert into public.rvn_admins(user_id) values('UUID-AKUN-ADMIN');
```

6. Buka Project Settings > API. Salin Project URL dan anon/public key.

## B. Deploy dari HP Android

1. Ekstrak ZIP di HP jika perlu. Buka github.com lewat Chrome dan aktifkan Situs desktop.
2. Buat repository baru bernama `rvn-selection`.
3. Unggah seluruh isi folder proyek ke repository, termasuk `app`, `lib`, `supabase`, `package.json`, dan `tsconfig.json`. Jangan unggah file rahasia.
4. Buka vercel.com, login dengan GitHub, pilih Add New > Project, lalu impor repository `rvn-selection`.
5. Di Environment Variables Vercel tambahkan:
   - `NEXT_PUBLIC_SUPABASE_URL` = Project URL Supabase
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY` = anon/public key Supabase
6. Tekan Deploy. Jika sukses, Vercel memberi URL `https://...vercel.app`.
7. Setiap perubahan di GitHub biasanya memicu deploy baru. Tes dahulu dengan peserta percobaan.

## C. Catatan keamanan dan status

- Login admin memakai Supabase Auth; hanya UUID yang dimasukkan ke `rvn_admins` boleh membaca hasil/laporan melalui RLS.
- Token peserta bersama mudah tersebar; bagikan hanya kepada peserta yang lolos tahap sebelumnya dan ganti setelah seleksi.
- Laporan browser bukan bukti pasti kecurangan. Browser tidak bisa mengawasi layar/aplikasi lain secara menyeluruh. Berikan aturan yang jelas dan tinjau laporan sebelum keputusan final.
- Pastikan seluruh 20 soal dimasukkan dan lakukan tes alur mulai, jawab, submit, timer, laporan, login admin, RLS, dan ekspor sebelum dibagikan.
