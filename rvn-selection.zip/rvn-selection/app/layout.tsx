import type { Metadata } from 'next';
import './styles.css';
export const metadata: Metadata = { title: 'RVN | Seleksi Wawancara', description: 'Portal seleksi online RVN' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="id"><body>{children}</body></html>;
}
