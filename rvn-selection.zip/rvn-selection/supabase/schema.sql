-- Jalankan di Supabase SQL Editor. Ganti token awal sebelum seleksi dibuka.
create extension if not exists pgcrypto;
create table if not exists public.rvn_settings (
  id boolean primary key default true check (id),
  exam_token text not null,
  duration_seconds int not null default 1800,
  terminate_on_violation boolean not null default true,
  updated_at timestamptz not null default now()
);
insert into public.rvn_settings(id,exam_token,duration_seconds,terminate_on_violation)
values(true,'GANTI-TOKEN-RVN-2026',1800,true) on conflict(id) do nothing;
create table if not exists public.rvn_questions (
  id text primary key,
  prompt text not null,
  options jsonb not null,
  answer_index int not null check(answer_index between 0 and 3),
  active boolean not null default true
);

-- Bank soal awal: kunci merupakan contoh rekomendasi dan wajib ditinjau admin RVN.
insert into public.rvn_questions(id,prompt,options,answer_index) values
('q1','Anggota tim menolak membantu persiapan kegiatan RVN. Apa tindakan paling tepat?','["Langsung melaporkannya tanpa bicara","Menanyakan kendalanya dan mengajak mencari solusi","Membalas dengan menolak membantu tugasnya","Membiarkannya tanpa koordinasi"]'::jsonb,1),
('q2','Kamu menerima kritik dari admin tentang hasil kerjamu. Bagaimana responsmu?','["Membantah agar tidak terlihat salah","Mengabaikan kritik tersebut","Mendengarkan, meminta contoh, lalu memperbaiki","Menyalahkan anggota lain"]'::jsonb,2),
('q3','Dua anggota berbeda pendapat saat menentukan konsep cover. Apa yang kamu lakukan?','["Memaksakan ide sendiri","Membantu membandingkan ide berdasarkan kebutuhan tim","Meminta salah satu keluar dari tim","Menghentikan proyek"]'::jsonb,1),
('q4','Kamu terlambat menyelesaikan tugas yang sudah disepakati. Apa langkah terbaik?','["Diam sampai ada yang bertanya","Membuat alasan yang tidak benar","Menyalahkan jadwal orang lain","Memberi kabar secepatnya, menjelaskan kendala, dan menyusun target baru"]'::jsonb,3),
('q5','Kamu melihat teman membagikan token ujian kepada orang lain. Apa tindakanmu?','["Ikut membagikannya","Mengingatkan agar berhenti dan melaporkan melalui jalur resmi","Menyebarkan kejadian itu ke semua grup","Menggunakan token tersebut"]'::jsonb,1),
('q6','Saat latihan cover, satu anggota terus melakukan kesalahan. Apa respons paling membantu?','["Mengejeknya agar lebih serius","Mengeluarkannya tanpa diskusi","Memberi masukan spesifik dan menawarkan latihan bersama","Mengambil semua bagiannya"]'::jsonb,2),
('q7','Admin memberi instruksi yang belum kamu pahami. Apa yang sebaiknya dilakukan?','["Meminta penjelasan sebelum mulai","Menebak dan menyalahkan admin jika salah","Mengabaikannya","Meminta peserta lain mengerjakan semuanya"]'::jsonb,0),
('q8','Kamu tidak setuju dengan keputusan tim yang sudah disepakati. Bagaimana menyikapinya?','["Mengacaukan pelaksanaan","Menyampaikan alasan dengan sopan lalu menghormati keputusan bersama","Menyindir tim di publik","Berhenti merespons tanpa kabar"]'::jsonb,1),
('q9','Informasi internal RVN tidak sengaja terkirim ke grup umum. Apa langkah awal yang tepat?','["Menghapus bukti lalu diam","Menyalahkan penerima","Menyebarkan lebih luas","Memberi tahu admin dan membantu membatasi penyebaran"]'::jsonb,3),
('q10','Kamu punya ide promosi baru, tetapi waktunya sangat dekat. Apa yang kamu lakukan?','["Langsung mengganti rencana tim","Membatalkan semua pekerjaan lama","Menyampaikan ide beserta kebutuhan waktunya dan meminta keputusan tim","Mengerjakan diam-diam tanpa koordinasi"]'::jsonb,2),
('q11','Seorang anggota meminta kamu mengisi kehadirannya padahal ia tidak hadir. Apa responsmu?','["Menolak dengan sopan dan menyampaikan data sebenarnya","Membantunya demi pertemanan","Mengubah data jika tidak ada yang melihat","Meminta imbalan"]'::jsonb,0),
('q12','Kamu menerima tugas baru ketika tugas lama belum selesai. Apa tindakan terbaik?','["Mengerjakan yang paling mudah saja","Membandingkan prioritas dan mengomunikasikan kapasitas kepada admin","Menghilang dari grup","Mengatakan semua selesai padahal belum"]'::jsonb,1),
('q13','Ada rumor tentang anggota RVN yang belum jelas kebenarannya. Apa yang kamu lakukan?','["Meneruskannya sebagai peringatan","Membuat cerita tambahan","Tidak menyebarkannya dan memeriksa fakta lewat jalur yang tepat","Menjadikannya bahan candaan publik"]'::jsonb,2),
('q14','Dalam rapat online, koneksi internetmu sering terputus. Apa yang sebaiknya dilakukan?','["Tetap diam dan dianggap hadir","Menyalahkan semua peserta","Meninggalkan rapat tanpa kabar","Memberi tahu tim dan meminta rangkuman atau tindak lanjut"]'::jsonb,3),
('q15','Anggota baru belum memahami alur kerja. Bagaimana kamu membantunya?','["Mengatakan ia seharusnya sudah tahu","Menjelaskan alur dan menunjukkan contoh yang relevan","Membiarkannya membuat kesalahan","Mengambil alih seluruh tugasnya"]'::jsonb,1),
('q16','Kamu menemukan kesalahan pada poster yang sudah dipublikasikan. Apa langkah terbaik?','["Menyembunyikan kesalahan","Menyalahkan desainer di grup","Memberi tahu tim dan membantu menerbitkan koreksi","Menghapus akun promosi"]'::jsonb,2),
('q17','Dua tugas penting memiliki tenggat yang sama. Apa yang kamu lakukan?','["Menentukan prioritas bersama admin berdasarkan dampak dan urgensi","Memilih secara acak","Tidak mengerjakan keduanya","Berjanji menyelesaikan semua tanpa rencana"]'::jsonb,0),
('q18','Teman dekatmu melanggar aturan seleksi. Bagaimana kamu menyikapinya?','["Membiarkan karena teman","Membantu menutupi kejadian","Menghapus laporan","Mengikuti aturan yang sama dan menyampaikan fakta secara objektif"]'::jsonb,3),
('q19','Setelah kegiatan selesai, hasil tim kurang sesuai target. Apa respons paling konstruktif?','["Mencari satu orang untuk disalahkan","Mengevaluasi proses, mengumpulkan masukan, dan menetapkan perbaikan","Berpura-pura target tercapai","Tidak mau ikut kegiatan lagi"]'::jsonb,1),
('q20','Kamu tidak bisa hadir pada jadwal yang sudah disepakati. Apa yang paling bertanggung jawab?','["Tidak datang tanpa kabar","Memberi tahu setelah acara selesai","Mengabari sedini mungkin dan membantu mencari pengganti atau solusi","Meminta orang lain berbohong untukmu"]'::jsonb,2)
on conflict(id) do nothing;

create table if not exists public.rvn_exam_sessions (
  id uuid primary key default gen_random_uuid(),
  participant_code text unique not null,
  participant_name text not null,
  started_at timestamptz not null default now(),
  expires_at timestamptz not null,
  status text not null default 'in_progress' check(status in ('in_progress','submitted','terminated','expired')),
  submitted_at timestamptz,
  score numeric(5,2),
  answers jsonb
);
create table if not exists public.rvn_violation_reports (
  id uuid primary key default gen_random_uuid(),
  participant_code text not null,
  participant_name text not null,
  event_type text not null,
  details text,
  terminate_exam boolean not null default false,
  created_at timestamptz not null default now()
);
create table if not exists public.rvn_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
create or replace view public.rvn_exam_results with (security_invoker=true) as
 select id,participant_code,participant_name,status,score,started_at,submitted_at from public.rvn_exam_sessions;

alter table public.rvn_settings enable row level security;
alter table public.rvn_questions enable row level security;
alter table public.rvn_exam_sessions enable row level security;
alter table public.rvn_violation_reports enable row level security;
alter table public.rvn_admins enable row level security;
create or replace function public.is_rvn_admin() returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from public.rvn_admins where user_id=auth.uid()) $$;
-- Semua tabel ditutup untuk akses langsung; gunakan RPC dan admin yang terautentikasi.
revoke all on public.rvn_settings,public.rvn_questions,public.rvn_exam_sessions,public.rvn_violation_reports,public.rvn_admins from anon, authenticated;
grant select on public.rvn_exam_results to authenticated;
grant select on public.rvn_exam_sessions, public.rvn_violation_reports, public.rvn_admins to authenticated;
create policy "admins read results" on public.rvn_exam_sessions for select to authenticated using(public.is_rvn_admin());
create policy "admins read violations" on public.rvn_violation_reports for select to authenticated using(public.is_rvn_admin());
create policy "admins read admin list" on public.rvn_admins for select to authenticated using(public.is_rvn_admin());

create or replace function public.start_rvn_exam(p_name text,p_token text) returns jsonb
language plpgsql security definer set search_path=public as $$
declare v_code text; v_settings public.rvn_settings%rowtype;
begin
 select * into v_settings from public.rvn_settings where id=true;
 if v_settings.id is null or p_token is distinct from v_settings.exam_token then raise exception 'Token seleksi tidak valid.'; end if;
 if length(trim(coalesce(p_name,'')))<2 then raise exception 'Nama peserta wajib diisi.'; end if;
 v_code := 'RVN-'||upper(substr(encode(gen_random_bytes(5),'hex'),1,8));
 insert into public.rvn_exam_sessions(participant_code,participant_name,expires_at) values(v_code,trim(p_name),now()+make_interval(secs=>v_settings.duration_seconds));
 return jsonb_build_object('code',v_code,'expires_at',now()+make_interval(secs=>v_settings.duration_seconds));
end $$;

create or replace function public.submit_rvn_exam(p_code text,p_answers jsonb,p_auto_submit boolean default false) returns jsonb
language plpgsql security definer set search_path=public as $$
declare s public.rvn_exam_sessions%rowtype; total int; correct int; final_status text;
begin
 select * into s from public.rvn_exam_sessions where participant_code=p_code for update;
 if s.id is null then raise exception 'Sesi ujian tidak ditemukan.'; end if;
 if s.status <> 'in_progress' then raise exception 'Ujian sudah ditutup.'; end if;
 if now()>s.expires_at then update public.rvn_exam_sessions set status='expired',submitted_at=now() where id=s.id; raise exception 'Waktu ujian habis.'; end if;
 select count(*) into total from public.rvn_questions where active;
 select count(*) into correct from jsonb_array_elements(coalesce(p_answers,'[]'::jsonb)) a join public.rvn_questions q on q.id=a->>'question_id' where q.active and (a->>'answer_index') ~ '^[0-3]$' and (a->>'answer_index')::int=q.answer_index;
 final_status := case when p_auto_submit then 'submitted' else 'submitted' end;
 update public.rvn_exam_sessions set status=final_status,submitted_at=now(),score=case when total=0 then null else round(correct::numeric*100/total,2) end,answers=p_answers where id=s.id;
 return jsonb_build_object('status',final_status,'score',case when total=0 then null else round(correct::numeric*100/total,2) end);
end $$;

create or replace function public.record_rvn_violation(p_code text,p_name text,p_event text,p_details text,p_terminate boolean default false) returns jsonb
language plpgsql security definer set search_path=public as $$
declare s public.rvn_exam_sessions%rowtype; should_terminate boolean;
begin
 select * into s from public.rvn_exam_sessions where participant_code=p_code for update;
 if s.id is null or s.status <> 'in_progress' then return jsonb_build_object('recorded',false); end if;
 select terminate_on_violation into should_terminate from public.rvn_settings where id=true;
 insert into public.rvn_violation_reports(participant_code,participant_name,event_type,details,terminate_exam)
 values(s.participant_code,s.participant_name,left(coalesce(p_event,'Kejadian tidak diketahui'),120),left(coalesce(p_details,''),1000),coalesce(p_terminate,false) and coalesce(should_terminate,true));
 if coalesce(p_terminate,false) and coalesce(should_terminate,true) then update public.rvn_exam_sessions set status='terminated',submitted_at=now() where id=s.id; end if;
 return jsonb_build_object('recorded',true,'terminated',coalesce(p_terminate,false) and coalesce(should_terminate,true));
end $$;
revoke all on function public.start_rvn_exam(text,text) from public;
revoke all on function public.submit_rvn_exam(text,jsonb,boolean) from public;
revoke all on function public.record_rvn_violation(text,text,text,text,boolean) from public;
grant execute on function public.start_rvn_exam(text,text) to anon,authenticated;
grant execute on function public.submit_rvn_exam(text,jsonb,boolean) to anon,authenticated;
grant execute on function public.record_rvn_violation(text,text,text,text,boolean) to anon,authenticated;
